	//Declaración de variables

	//Nombre del dueño de la Cuenta Home Banking.
	var nombreUsuario = "Gustavo Velasquez";
	//Valor inicial del saldo de la Cuenta Home Banking.
	var saldoCuenta = 25000;
	//Valor inicial que limita la extracción.
	var limiteExtraccion = 3000;
	//Servicio para pagar desde Cuenta Home Banking.
	var servicioDeTelefono = 350;
	//Servicio para pagar desde Cuenta Home Banking.
	var servicioDeAgua = 450;
	//Servicio para pagar desde Cuenta Home Banking.
	var servicioDeLuz = 210;
	//Servicio para pagar desde Cuenta Home Banking.
	var servicioDeInternet = 570;
	//Cuenta destino para transferencias.
	var cuentaAmiga1 = "1234567";
	//Cuenta destino para transferencias.
	var cuentaAmiga2 = "7654321";
	//Clave de acceso a Cuenta Home Banking.
	var claveDeSeguridad = "1234";
	//Cantidad de intentos erroneos a la cuenta Home Banking.
	var cantLogueosErroneos = 0;

	//Ejecución de las funciones que actualizan los valores de las variables en el HTML.
	window.onload = function() {
		iniciarSesion();
	   	cargarNombreEnPantalla();
	   	actualizarSaldoEnPantalla();
	   	actualizarLimiteEnPantalla();
	}

	// Recibe valor a sumar a saldo de cuenta.
	function sumarDineroACuenta(valorADepositar){
		saldoCuenta += valorADepositar;
	}

	// Recibe valor a restar a saldo de cuenta.
	function restaDineroACuenta(valorAExtraer){
		saldoCuenta -= valorAExtraer;
	}

	/* Valida si el valor ingresado por el usuario cumple con los siguientes puntos:
		1- Es menor o igual al saldo cuenta actual.
		2- Es menor o igual al límite de extracción actual.
		3- Es multiplo de 100.
	*/
	function validaExtraccion(valorAExtraer){
		let valorValido = true;
		if(valorAExtraer > saldoCuenta){
			alert("Saldo insuficiente para realizar la extracción deseada.");
			valorValido = false;
		}else if(valorAExtraer > limiteExtraccion){
			alert("Saldo supera el límite de extracción.");
			valorValido = false;
		}else if(valorAExtraer % 100 != 0){
			alert("Solo puedes extraer billetes de $100.");
			valorValido = false;
		}
		return valorValido;
	}

	// Función booleana que verifica si el valor ingresado por el usuario es numérico o no.
	function esValorNumerico(monto){
		let esNumerico = true;
		if (!Number.isInteger(monto)){
			esNumerico = false;
			alert("El valor ingresado no es un número.");
		}
		return esNumerico;
	}

	// Modifica el límite de extracción.
	function cambiarLimiteDeExtraccion() {
		let nuevoLimiteExtraccion = parseInt(prompt("Ingrese el limite de extracción de su cuenta:"));
		if(esValorNumerico(nuevoLimiteExtraccion)){
			limiteExtraccion = nuevoLimiteExtraccion;
			actualizarLimiteEnPantalla();
			alert("Nuevo límite de extracción: $"+limiteExtraccion);
		}
	}

	// Extrae dinero, disminuyendo el valor de saldoCuenta.
	function extraerDinero() {
		let valorAExtraer = parseInt(prompt("Ingrese el saldo que desea extraer:"));
		let saldoCuentaAnterior = saldoCuenta;
		if(esValorNumerico(valorAExtraer) && validaExtraccion(valorAExtraer)){
			restaDineroACuenta(valorAExtraer);
			actualizarSaldoEnPantalla();
			alert("Detalles de transacción:\n Has extraido: " + valorAExtraer + 
			  "\n Saldo anterior: " + saldoCuentaAnterior + 
			  "\n Saldo actual: " + saldoCuenta);
		}
	}

	// Deposita dinero, aumentando el valor de saldoCuenta.
	function depositarDinero() {
		let valorADepositar = parseInt(prompt("Ingrese el saldo que desea depositar:"));
		let saldoCuentaAnterior = saldoCuenta;
		if (esValorNumerico(valorADepositar)) {
			sumarDineroACuenta(valorADepositar);
			actualizarSaldoEnPantalla();
			alert("Detalles de transacción:\n Has depositado: $" + valorADepositar	 + 
			  "\n Saldo anterior: $" + saldoCuentaAnterior + 
			  "\n Saldo actual: $" + saldoCuenta);
		}
	}

	// Realiza el pago de un servicio seleccionado, disminuyendo el valor de saldoCuenta.
	function pagarServicio() {
		let numeroDeServicio = parseInt(prompt("Seleccione el Sevicio que desea pagar: \n 1- Agua \n 2 - Luz \n 3 - Teléfono \n 4 - Internet"));
		let saldoCuentaAnterior;
		if(esValorNumerico(numeroDeServicio)){
			switch(numeroDeServicio){
				case 1:
					if(servicioDeAgua > saldoCuenta){
						alert("Saldo insuficiente para realizar este pago.");
					}else{
						saldoCuentaAnterior = saldoCuenta;
						saldoCuenta -= servicioDeAgua;
						actualizarSaldoEnPantalla();
						alert("Has pagado el servicio de Agua. \n Saldo anterior: $"+ saldoCuentaAnterior+
							  "\n Dinero descontado de la cuenta: $"+ servicioDeAgua+
							  "\n Saldo actual: $"+ saldoCuenta);
					}
					break;
				case 2:
					if(servicioDeLuz > saldoCuenta){
						alert("Saldo insuficiente para realizar este pago.");
					}else{
						saldoCuentaAnterior = saldoCuenta;
						saldoCuenta -= servicioDeLuz;
						actualizarSaldoEnPantalla();
						alert("Has pagado el servicio de Luz. \n Saldo anterior: $"+ saldoCuentaAnterior+
							  "\n Dinero descontado de la cuenta: $"+ servicioDeLuz+
							  "\n Saldo actual: $"+ saldoCuenta);
					}
					break;
				case 3:
					if(servicioDeTelefono > saldoCuenta){
						alert("Saldo insuficiente para realizar este pago.");
					}else{
						saldoCuentaAnterior = saldoCuenta;
						saldoCuenta -= servicioDeTelefono;
						actualizarSaldoEnPantalla();
						alert("Has pagado el servicio de Teléfono. \n Saldo anterior: $"+ saldoCuentaAnterior+
							  "\n Dinero descontado de la cuenta: $"+ servicioDeTelefono+
							  "\n Saldo actual: $"+ saldoCuenta);
					}
					break;
				case 4:
					if(servicioDeInternet > saldoCuenta){
						alert("Saldo insuficiente para realizar este pago.");
					}else{
						saldoCuentaAnterior = saldoCuenta;
						saldoCuenta -= servicioDeInternet;
						actualizarSaldoEnPantalla();
						alert("Has pagado el servicio de Internet. \n Saldo anterior: $"+ saldoCuentaAnterior+
							  "\n Dinero descontado de la cuenta: $"+ servicioDeInternet+
							  "\n Saldo actual: $"+ saldoCuenta);
					}
					break;
				default:
					alert("No existe el servicio que ha seleccionado.");
			}
		}
	}


	// Realiza transferencia de dinero a una cuenta seleccionada, disminuyendo el valor de saldoCuenta.
	function transferirDinero() {
		let montoATransferir = parseInt(prompt("Ingrese el monto que desea transferir: "));
		if(esValorNumerico(montoATransferir)){
			if (montoATransferir > saldoCuenta) {
				alert("Saldo insuficiente para realizar esta transferencia.");
			}else{
				let usuarioATransferir = parseInt(prompt("Seleccione la Cuenta Destino: \n 1 - Cuenta Amiga1 \n 2 - Cuenta Amiga2"));
				switch(usuarioATransferir){
					case 1:
						saldoCuenta -= montoATransferir;
						actualizarSaldoEnPantalla();
						alert("Detalles de Transferencia: \n Se ha transferido: $"+ montoATransferir+
							  "\n Cuenta Destino: "+ cuentaAmiga1);
						break;
					case 2:
						saldoCuenta -= montoATransferir;
						actualizarSaldoEnPantalla();
						alert("Detalles de Transferencia: \n Se ha transferido: $"+ montoATransferir+
							  "\n Cuenta Destino: "+ cuentaAmiga2);
						break;
					default:
						alert("No existe el usuario que ha seleccionado.");
				}
			}
		}

	}

	// Función que se encarga de validar la clave numérica ingresada por el usuario. Si falla 3 veces, bloquea la cuenta, retirando el saldo disponible.
	function iniciarSesion() {

		let codigoDeAcceso = parseInt(prompt("Ingrese su Clave de Acceso:"));
		while(cantLogueosErroneos < 3 && codigoDeAcceso != claveDeSeguridad) {
			codigoDeAcceso = parseInt(prompt("Clave de Acceso errónea. Vuelva a intentarlo:"));
			cantLogueosErroneos ++;
		}
		if(cantLogueosErroneos === 3){
			saldoCuenta = 0;
			alert("Ha superado la cantidad máxima de logueos.\n SU CUENTA HA SIDO BLOQUEADA!!\nTu dinero ha sido retenido por cuestiones de seguridad.");
		}else{
			alert("Bienvenido/a " + nombreUsuario + " ya puede comenzar a realizar operaciones.");
		}	
	}

	// Funciones que actualizan el valor de las variables en el HTML
	function cargarNombreEnPantalla() {
	    document.getElementById("nombre").innerHTML = "Bienvenido/a " + nombreUsuario;
	}

	function actualizarSaldoEnPantalla() {
	    document.getElementById("saldo-cuenta").innerHTML = "$" + saldoCuenta;
	}

	function actualizarLimiteEnPantalla() {
	    document.getElementById("limite-extraccion").innerHTML = "Tu límite de extracción es: $" + limiteExtraccion;
	}